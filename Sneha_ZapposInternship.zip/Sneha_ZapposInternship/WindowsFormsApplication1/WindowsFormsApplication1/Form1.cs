﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
//A desktop application which replicates the functionalities of a slot machine
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        bool myblnFlash1 = false;
        bool myblnFlash2 = false;
        bool myblnFlash3 = false;

        int myCash = 500; //This will be the cash the user has in the beginning
        int myCurrentBet = 100;

        private void Form1_Load(object sender, EventArgs e)
        {
            ShowScreen();
            
        }

        private void picBox5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnLever_Click(object sender, EventArgs e)
        {
            myCash -= myCurrentBet;
            tmrTimer1.Enabled = true;
            tmrTimer2.Enabled = true;
            tmrTimer3.Enabled = true;
        }
        
        private bool RandomStop()
        {
            Random rnd = new Random();
            int intRandom = rnd.Next(20);
            if (intRandom == 7)
            {
                return true;
            }
            return false;
        }

        private void tmrTimer1_Tick(object sender, EventArgs e)
        {
            RunTimer(lblOne, pictureBox1);
            if (RandomStop())
            {
                tmrTimer1.Enabled = false;
            }
        }

        private void RunTimer(Label lbl, PictureBox pic)
        {
            int intCounter = int.Parse(lbl.Text);
            intCounter += 1;
            if (intCounter >= 4)
            {
                intCounter = 1;
            }
            lbl.Text = intCounter.ToString();
            PictureBox picShow = (PictureBox)Controls.Find("picBox" + intCounter.ToString(), true)[0];
            pic.BackgroundImage = picShow.BackgroundImage;
            //The step above brings pictures from the bottom of the screen
            //on the three main picture boxes
        }

        private void tmrTimer2_Tick(object sender, EventArgs e)
        {
            RunTimer(lblTwo, pictureBox2);
            if (tmrTimer1.Enabled == false)
            {
                if (RandomStop())
                {
                    tmrTimer2.Enabled = false;
                }
            }
        }

        private void tmrTimer3_Tick(object sender, EventArgs e)
        {
            RunTimer(lblThree, pictureBox3);
            if (tmrTimer2.Enabled == false)
            {
                if (RandomStop())
                {
                    tmrTimer3.Enabled = false;
                    CheckIfWeWon();
                }
            }
        }

        void CheckIfWeWon()
        {
            //The labels above the picture are matched
            //to 'check-if-we-won'!
            myblnFlash1 = false;
            myblnFlash2 = false;
            myblnFlash3 = false;
            if (lblOne.Text == lblTwo.Text &&
                    lblTwo.Text == lblThree.Text)
            {
                myblnFlash1 = true;
                myblnFlash2 = true;
                myblnFlash3 = true;
                FlashBackgrounds();
                myCash += myCurrentBet * 10;
                 }
            else if (lblOne.Text == lblTwo.Text)
            {
                FlashBackgrounds();
                myblnFlash1 = true;
                myblnFlash2 = true;
                myCash += myCurrentBet;
                
            }
            else if (lblThree.Text == lblTwo.Text)
            {
                FlashBackgrounds();
                myblnFlash3 = true;
                myblnFlash2 = true;
                myCash += myCurrentBet;
                
            }
            else if (lblOne.Text == lblThree.Text)
            {
                FlashBackgrounds();
                myblnFlash1 = true;
                myblnFlash3 = true;
                myCash += myCurrentBet;
                
            }

            ShowScreen();
        }
        void FlashBackgrounds()
        {
            //This will flash windows to tell the user that they have won
            tmrFlash.Enabled = true;
        }
        private void ShowScreen()
        {
            //This will show the screen with the current bet and current cash
            lblBet.Text = myCurrentBet.ToString("C");
            lblCashRemaining.Text = myCash.ToString("C");
            if (myCash < 600)
            {
                btnBet600.Visible = false;
            }
            //The option to bet $600 will only appear once the user has more than 500.
            //We have initialized his amount to 500 only.
            else
            {
                btnBet600.Visible = true;
            }

            if (myCash <= 0)
            {
                MessageBox.Show("Do you want to collect fruits again?", "At your own cost!", MessageBoxButtons.OKCancel);
                ResetTheScreen();
            }
        }

        void ResetTheScreen()
        {
            myCurrentBet = 100;
            myCash = 500;
            ShowScreen();
        }
        private void lblCashRemainingLabel_Click(object sender, EventArgs e)
        {
            //Called by mistake - No functionality
        }

        private void tmrFlash_Tick(object sender, EventArgs e)
        {
            Color clrNextColor = picFlash1.BackColor;
            if (clrNextColor == Color.Red)
            {
                clrNextColor = Color.Plum;
            }
            else if (clrNextColor == Color.Plum)
            {
                clrNextColor = Color.PowderBlue;
            }
            else
            {
                clrNextColor = Color.Red;
            }
            picFlash1.BackColor = clrNextColor;
            picFlash2.BackColor = clrNextColor;
            picFlash3.BackColor = clrNextColor;
            picFlash1.Visible = myblnFlash1;
            picFlash2.Visible = myblnFlash2;
            picFlash3.Visible = myblnFlash3;

            if (RandomStop())
            {
                tmrFlash.Enabled = false;
                myblnFlash1 = false;
                myblnFlash2 = false;
                myblnFlash3 = false;
                picFlash1.Visible = myblnFlash1;
                picFlash2.Visible = myblnFlash2;
                picFlash3.Visible = myblnFlash3;
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            ResetTheScreen();
        }

        private void picFlash1_Click(object sender, EventArgs e)
        {
            //Called by mistake - No functionality
        }

        private void btnBet600_Click(object sender, EventArgs e)
        {
            myCurrentBet = 600;
            ShowScreen();
        }

        private void btnBetMax_Click(object sender, EventArgs e)
        {
            myCurrentBet = myCash;
            ShowScreen();
        }

        private void btnBet100_Click(object sender, EventArgs e)
        {
            myCurrentBet = 100;
            ShowScreen();

        }
    }
}
