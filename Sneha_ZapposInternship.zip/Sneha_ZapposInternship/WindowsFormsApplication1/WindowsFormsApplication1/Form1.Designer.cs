﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.lblOne = new System.Windows.Forms.Label();
            this.lblTwo = new System.Windows.Forms.Label();
            this.lblThree = new System.Windows.Forms.Label();
            this.btnLever = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.picBox7 = new System.Windows.Forms.PictureBox();
            this.picBox6 = new System.Windows.Forms.PictureBox();
            this.picBox4 = new System.Windows.Forms.PictureBox();
            this.picBox3 = new System.Windows.Forms.PictureBox();
            this.picBox2 = new System.Windows.Forms.PictureBox();
            this.picBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.picFlash3 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tmrTimer1 = new System.Windows.Forms.Timer(this.components);
            this.tmrTimer2 = new System.Windows.Forms.Timer(this.components);
            this.tmrTimer3 = new System.Windows.Forms.Timer(this.components);
            this.lblBetLabel = new System.Windows.Forms.Label();
            this.lblBet = new System.Windows.Forms.Label();
            this.lblCashRemainingLabel = new System.Windows.Forms.Label();
            this.lblCashRemaining = new System.Windows.Forms.Label();
            this.tmrFlash = new System.Windows.Forms.Timer(this.components);
            this.btnBet600 = new System.Windows.Forms.Button();
            this.btnBetMax = new System.Windows.Forms.Button();
            this.btnBet100 = new System.Windows.Forms.Button();
            this.picFlash1 = new System.Windows.Forms.PictureBox();
            this.picFlash2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureCentre = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlash3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlash1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlash2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCentre)).BeginInit();
            this.SuspendLayout();
            // 
            // lblOne
            // 
            this.lblOne.AutoSize = true;
            this.lblOne.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblOne.Location = new System.Drawing.Point(90, 53);
            this.lblOne.Name = "lblOne";
            this.lblOne.Size = new System.Drawing.Size(13, 13);
            this.lblOne.TabIndex = 0;
            this.lblOne.Text = "1";
            // 
            // lblTwo
            // 
            this.lblTwo.AutoSize = true;
            this.lblTwo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblTwo.Location = new System.Drawing.Point(220, 53);
            this.lblTwo.Name = "lblTwo";
            this.lblTwo.Size = new System.Drawing.Size(13, 13);
            this.lblTwo.TabIndex = 1;
            this.lblTwo.Text = "2";
            // 
            // lblThree
            // 
            this.lblThree.AutoSize = true;
            this.lblThree.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblThree.Location = new System.Drawing.Point(357, 53);
            this.lblThree.Name = "lblThree";
            this.lblThree.Size = new System.Drawing.Size(13, 13);
            this.lblThree.TabIndex = 2;
            this.lblThree.Text = "3";
            // 
            // btnLever
            // 
            this.btnLever.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnLever.Image = ((System.Drawing.Image)(resources.GetObject("btnLever.Image")));
            this.btnLever.Location = new System.Drawing.Point(543, 255);
            this.btnLever.Name = "btnLever";
            this.btnLever.Size = new System.Drawing.Size(103, 128);
            this.btnLever.TabIndex = 8;
            this.btnLever.Text = "Push Me";
            this.btnLever.UseVisualStyleBackColor = false;
            this.btnLever.Click += new System.EventHandler(this.btnLever_Click);
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.btnReset.Image = ((System.Drawing.Image)(resources.GetObject("btnReset.Image")));
            this.btnReset.Location = new System.Drawing.Point(543, 200);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(103, 23);
            this.btnReset.TabIndex = 7;
            this.btnReset.Text = "Reset";
            this.btnReset.UseVisualStyleBackColor = false;
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images__3_;
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Location = new System.Drawing.Point(67, 420);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(100, 50);
            this.pictureBox5.TabIndex = 16;
            this.pictureBox5.TabStop = false;
            // 
            // picBox7
            // 
            this.picBox7.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images__1_;
            this.picBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBox7.Location = new System.Drawing.Point(279, 420);
            this.picBox7.Name = "picBox7";
            this.picBox7.Size = new System.Drawing.Size(100, 50);
            this.picBox7.TabIndex = 15;
            this.picBox7.TabStop = false;
            // 
            // picBox6
            // 
            this.picBox6.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images__2_;
            this.picBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBox6.Location = new System.Drawing.Point(173, 420);
            this.picBox6.Name = "picBox6";
            this.picBox6.Size = new System.Drawing.Size(100, 50);
            this.picBox6.TabIndex = 14;
            this.picBox6.TabStop = false;
            // 
            // picBox4
            // 
            this.picBox4.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images__4_;
            this.picBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBox4.Location = new System.Drawing.Point(345, 364);
            this.picBox4.Name = "picBox4";
            this.picBox4.Size = new System.Drawing.Size(100, 50);
            this.picBox4.TabIndex = 12;
            this.picBox4.TabStop = false;
            // 
            // picBox3
            // 
            this.picBox3.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images__5_;
            this.picBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBox3.Location = new System.Drawing.Point(239, 364);
            this.picBox3.Name = "picBox3";
            this.picBox3.Size = new System.Drawing.Size(100, 50);
            this.picBox3.TabIndex = 11;
            this.picBox3.TabStop = false;
            // 
            // picBox2
            // 
            this.picBox2.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images__6_;
            this.picBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBox2.Location = new System.Drawing.Point(133, 364);
            this.picBox2.Name = "picBox2";
            this.picBox2.Size = new System.Drawing.Size(100, 50);
            this.picBox2.TabIndex = 10;
            this.picBox2.TabStop = false;
            // 
            // picBox1
            // 
            this.picBox1.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images;
            this.picBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picBox1.Location = new System.Drawing.Point(27, 364);
            this.picBox1.Name = "picBox1";
            this.picBox1.Size = new System.Drawing.Size(100, 50);
            this.picBox1.TabIndex = 9;
            this.picBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Location = new System.Drawing.Point(-23, -46);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(100, 50);
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // picFlash3
            // 
            this.picFlash3.Location = new System.Drawing.Point(312, 81);
            this.picFlash3.Name = "picFlash3";
            this.picFlash3.Size = new System.Drawing.Size(125, 80);
            this.picFlash3.TabIndex = 5;
            this.picFlash3.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(188, 95);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(100, 50);
            this.pictureBox2.TabIndex = 4;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(52, 95);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(100, 50);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.textBox1.Location = new System.Drawing.Point(112, 211);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(126, 20);
            this.textBox1.TabIndex = 17;
            this.textBox1.Text = "Fruit Baskets, anyone?";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // tmrTimer1
            // 
            this.tmrTimer1.Tick += new System.EventHandler(this.tmrTimer1_Tick);
            // 
            // tmrTimer2
            // 
            this.tmrTimer2.Tick += new System.EventHandler(this.tmrTimer2_Tick);
            // 
            // tmrTimer3
            // 
            this.tmrTimer3.Tick += new System.EventHandler(this.tmrTimer3_Tick);
            // 
            // lblBetLabel
            // 
            this.lblBetLabel.AutoSize = true;
            this.lblBetLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblBetLabel.Location = new System.Drawing.Point(509, 67);
            this.lblBetLabel.Name = "lblBetLabel";
            this.lblBetLabel.Size = new System.Drawing.Size(60, 13);
            this.lblBetLabel.TabIndex = 21;
            this.lblBetLabel.Text = "Current Bet";
            // 
            // lblBet
            // 
            this.lblBet.AutoSize = true;
            this.lblBet.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblBet.Location = new System.Drawing.Point(593, 68);
            this.lblBet.Name = "lblBet";
            this.lblBet.Size = new System.Drawing.Size(35, 13);
            this.lblBet.TabIndex = 20;
            this.lblBet.Text = "label2";
            // 
            // lblCashRemainingLabel
            // 
            this.lblCashRemainingLabel.AutoSize = true;
            this.lblCashRemainingLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblCashRemainingLabel.Location = new System.Drawing.Point(506, 41);
            this.lblCashRemainingLabel.Name = "lblCashRemainingLabel";
            this.lblCashRemainingLabel.Size = new System.Drawing.Size(84, 13);
            this.lblCashRemainingLabel.TabIndex = 19;
            this.lblCashRemainingLabel.Text = "Cash Remaining";
            this.lblCashRemainingLabel.Click += new System.EventHandler(this.lblCashRemainingLabel_Click);
            // 
            // lblCashRemaining
            // 
            this.lblCashRemaining.AutoSize = true;
            this.lblCashRemaining.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.lblCashRemaining.Location = new System.Drawing.Point(593, 41);
            this.lblCashRemaining.Name = "lblCashRemaining";
            this.lblCashRemaining.Size = new System.Drawing.Size(35, 13);
            this.lblCashRemaining.TabIndex = 18;
            this.lblCashRemaining.Text = "label1";
            // 
            // tmrFlash
            // 
            this.tmrFlash.Tick += new System.EventHandler(this.tmrFlash_Tick);
            // 
            // btnBet600
            // 
            this.btnBet600.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBet600.Location = new System.Drawing.Point(198, 182);
            this.btnBet600.Name = "btnBet600";
            this.btnBet600.Size = new System.Drawing.Size(75, 23);
            this.btnBet600.TabIndex = 29;
            this.btnBet600.Text = "Bet 600";
            this.btnBet600.UseVisualStyleBackColor = false;
            this.btnBet600.Click += new System.EventHandler(this.btnBet600_Click);
            // 
            // btnBetMax
            // 
            this.btnBetMax.BackColor = System.Drawing.Color.Red;
            this.btnBetMax.Location = new System.Drawing.Point(345, 182);
            this.btnBetMax.Name = "btnBetMax";
            this.btnBetMax.Size = new System.Drawing.Size(75, 23);
            this.btnBetMax.TabIndex = 28;
            this.btnBetMax.Text = "Bet Max";
            this.btnBetMax.UseVisualStyleBackColor = false;
            this.btnBetMax.Click += new System.EventHandler(this.btnBetMax_Click);
            // 
            // btnBet100
            // 
            this.btnBet100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBet100.Location = new System.Drawing.Point(67, 182);
            this.btnBet100.Name = "btnBet100";
            this.btnBet100.Size = new System.Drawing.Size(75, 23);
            this.btnBet100.TabIndex = 27;
            this.btnBet100.Text = "Bet 100";
            this.btnBet100.UseVisualStyleBackColor = false;
            this.btnBet100.Click += new System.EventHandler(this.btnBet100_Click);
            // 
            // picFlash1
            // 
            this.picFlash1.Location = new System.Drawing.Point(40, 81);
            this.picFlash1.Name = "picFlash1";
            this.picFlash1.Size = new System.Drawing.Size(127, 80);
            this.picFlash1.TabIndex = 30;
            this.picFlash1.TabStop = false;
            this.picFlash1.Click += new System.EventHandler(this.picFlash1_Click);
            // 
            // picFlash2
            // 
            this.picFlash2.Location = new System.Drawing.Point(173, 81);
            this.picFlash2.Name = "picFlash2";
            this.picFlash2.Size = new System.Drawing.Size(133, 80);
            this.picFlash2.TabIndex = 31;
            this.picFlash2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(326, 94);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(100, 50);
            this.pictureBox3.TabIndex = 32;
            this.pictureBox3.TabStop = false;
            // 
            // pictureCentre
            // 
            this.pictureCentre.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images__7_;
            this.pictureCentre.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureCentre.Location = new System.Drawing.Point(112, 229);
            this.pictureCentre.Name = "pictureCentre";
            this.pictureCentre.Size = new System.Drawing.Size(288, 114);
            this.pictureCentre.TabIndex = 33;
            this.pictureCentre.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.images1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(675, 515);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.btnBet600);
            this.Controls.Add(this.btnBetMax);
            this.Controls.Add(this.btnBet100);
            this.Controls.Add(this.lblBetLabel);
            this.Controls.Add(this.lblBet);
            this.Controls.Add(this.lblCashRemainingLabel);
            this.Controls.Add(this.lblCashRemaining);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.picBox7);
            this.Controls.Add(this.picBox6);
            this.Controls.Add(this.picBox4);
            this.Controls.Add(this.picBox3);
            this.Controls.Add(this.picBox2);
            this.Controls.Add(this.picBox1);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.btnReset);
            this.Controls.Add(this.btnLever);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.lblThree);
            this.Controls.Add(this.lblTwo);
            this.Controls.Add(this.lblOne);
            this.Controls.Add(this.picFlash1);
            this.Controls.Add(this.picFlash2);
            this.Controls.Add(this.picFlash3);
            this.Controls.Add(this.pictureCentre);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlash3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlash1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picFlash2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureCentre)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblOne;
        private System.Windows.Forms.Label lblTwo;
        private System.Windows.Forms.Label lblThree;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox picFlash3;
        private System.Windows.Forms.Button btnLever;
        private System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox picBox1;
        private System.Windows.Forms.PictureBox picBox2;
        private System.Windows.Forms.PictureBox picBox3;
        private System.Windows.Forms.PictureBox picBox4;
        private System.Windows.Forms.PictureBox picBox6;
        private System.Windows.Forms.PictureBox picBox7;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Timer tmrTimer1;
        private System.Windows.Forms.Timer tmrTimer2;
        private System.Windows.Forms.Timer tmrTimer3;
        private System.Windows.Forms.Label lblBetLabel;
        private System.Windows.Forms.Label lblBet;
        private System.Windows.Forms.Label lblCashRemainingLabel;
        private System.Windows.Forms.Label lblCashRemaining;
        private System.Windows.Forms.Timer tmrFlash;
        private System.Windows.Forms.Button btnBet600;
        private System.Windows.Forms.Button btnBetMax;
        private System.Windows.Forms.Button btnBet100;
        private System.Windows.Forms.PictureBox picFlash1;
        private System.Windows.Forms.PictureBox picFlash2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureCentre;
    }
}

